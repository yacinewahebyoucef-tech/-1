# BAC Academy DZ

واجهة عربية RTL لمنصة تعليمية جزائرية للتحضير للبكالوريا، مبنية باستخدام React + Vite وSupabase.

## الموجود في النسخة الأولية
- واجهة رئيسية متجاوبة للحاسوب والهاتف.
- صفحات للدروس والوثائق ومجتمع التلاميذ ومساعد الذكاء الاصطناعي (بعضها واجهات تمهيدية).
- تسجيل حساب وتسجيل دخول بالبريد وكلمة المرور عبر Supabase Auth.
- جلب الدورات المنشورة من قاعدة البيانات.
- نموذج إضافة دورة؛ قاعدة البيانات تسمح بالإضافة للمشرفين فقط.
- مخطط SQL للجداول وسياسات الحماية الأساسية.

> هذه نسخة تأسيسية قابلة للتطوير، وليست بعد منصة إنتاج مكتملة: لا يوجد دفع إلكتروني أو محادثة فعلية أو تخزين ملفات موصول بالواجهة أو تكامل AI. يلزم اختبار الأمان والإعداد قبل نشرها للطلاب.

## 1. المتطلبات
- تثبيت Node.js (إصدار LTS) من https://nodejs.org/
- حساب Supabase: https://supabase.com/
- حساب GitHub (اختياري لكنه يسهل النشر): https://github.com/
- حساب Vercel للنشر: https://vercel.com/

## 2. تشغيل الموقع على الحاسوب
افتح Terminal داخل مجلد المشروع ثم نفّذ:

```bash
npm install
npm run dev
```

افتح الرابط الذي يظهر في الطرفية، غالبًا `http://localhost:5173`.

## 3. إعداد قاعدة البيانات والحسابات
1. أنشئ مشروعًا جديدًا في Supabase.
2. افتح SQL Editor.
3. افتح الملف `supabase/schema.sql`، وانسخ محتواه كاملًا إلى SQL Editor ثم اضغط Run.
4. من إعدادات المشروع/Connect انسخ Project URL وPublishable key.
5. انسخ `.env.example` إلى ملف جديد اسمه `.env.local` في جذر المشروع، واملأ القيم:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_PUBLISHABLE_KEY`
6. أوقف خادم التطوير ثم شغّله مجددًا (`Ctrl+C` ثم `npm run dev`).
7. سجّل حسابًا من الموقع. افتح Supabase > Authentication > Users وخذ UUID الخاص بحسابك.
8. في SQL Editor نفّذ الأمر التالي بعد استبدال القيمة بمعرّف حسابك:

```sql
update public.profiles
set role = 'admin'
where id = 'ضع-UUID-حسابك-هنا';
```

**مهم:** لا تضع أبدًا `service_role` أو `secret key` في متغير يبدأ بـ `VITE_` أو داخل كود المتصفح. استخدم فقط المفتاح العام Publishable/anon مع سياسات RLS، ولا تجعل المستخدم مشرفًا من خلال الواجهة العامة.

## 4. نشره على الإنترنت عبر Vercel
الطريقة السهلة:
1. ارفع مجلد المشروع إلى مستودع GitHub جديد.
2. افتح https://vercel.com/ وسجّل الدخول بحساب GitHub.
3. اضغط Add New > Project واختر المستودع.
4. تأكد من إعدادات البناء:
   - Framework: Vite
   - Build command: `npm run build`
   - Output directory: `dist`
5. من Environment Variables أضف `VITE_SUPABASE_URL` و`VITE_SUPABASE_PUBLISHABLE_KEY` بنفس القيم الموجودة في `.env.local`.
6. اضغط Deploy.
7. بعد النشر، اختبر التسجيل وتسجيل الدخول وقراءة الدورات.
8. في Supabase Authentication > URL Configuration أضف رابط الموقع المنشور إلى Site URL وRedirect URLs إذا طلب الإعداد ذلك.

التعديلات التي تدفعها إلى GitHub يمكن أن تنشر تلقائيًا بعد ربط المشروع بـ Vercel.

## 5. إضافة أول دورة
بعد تنفيذ SQL وترقية حسابك إلى `admin`:
- سجّل الدخول.
- افتح «الدروس والدورات».
- افتح «إضافة دورة»، واملأ البيانات.
- في هذه النسخة يمكن وضع رابط فيديو عام. لا تضع روابط خاصة أو مدفوعة بشكل مكشوف؛ استخدم تخزينًا خاصًا وروابط موقعة عند تطوير الدورات المدفوعة.

## 6. قبل الإطلاق الحقيقي
- راجع سياسات RLS واختبرها بحساب طالب وحساب مشرف.
- أضف إدارة رفع الملفات إلى Supabase Storage وسياسات الوصول.
- أنشئ نظام صلاحيات واختبارات آلية.
- اربط مساعد الذكاء الاصطناعي بخادم آمن، ولا تضع مفتاح مزود AI في الواجهة.
- أضف صفحات سياسة الخصوصية وشروط الاستخدام ووسيلة تواصل.
- أضف نظام دفع مناسبًا للجزائر بعد التحقق من متطلبات مزود الدفع.
- اختبر الموقع على الهاتف والحاسوب والاتصال البطيء.

## مراجع
- Supabase React quickstart: https://supabase.com/docs/guides/getting-started/quickstarts/reactjs
- Supabase Auth: https://supabase.com/docs/guides/auth/quickstarts/react
- Vite deployment: https://vite.dev/guide/static-deploy.html
