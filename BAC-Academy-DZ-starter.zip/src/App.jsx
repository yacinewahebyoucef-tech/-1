import { useEffect, useState } from 'react'
import { BookOpen, GraduationCap, LayoutDashboard, FileText, BrainCircuit, Users, Search, Bell, Menu, X, PlayCircle, Clock3, ChevronLeft, Star, LogIn, UserPlus, LogOut, ShieldCheck, Sparkles, CircleHelp, CheckCircle2, LockKeyhole } from 'lucide-react'
import { hasSupabaseConfig, supabase } from './lib/supabase'

const sampleCourses = [
  { id: 'math', title: 'الدوال العددية', subject: 'الرياضيات', teacher: 'فريق BAC Academy', lessons: 12, duration: '4 س 20 د', level: 'مراجعة شاملة', color: 'blue', icon: '∫' },
  { id: 'physics', title: 'الميكانيك — قوانين نيوتن', subject: 'الفيزياء', teacher: 'فريق BAC Academy', lessons: 8, duration: '3 س 10 د', level: 'شرح وتمارين', color: 'purple', icon: 'F' },
  { id: 'science', title: 'التركيب الضوئي', subject: 'العلوم الطبيعية', teacher: 'فريق BAC Academy', lessons: 10, duration: '3 س 45 د', level: 'ملخصات وتمارين', color: 'green', icon: '✳' },
]
const subjects = ['الكل', 'الرياضيات', 'الفيزياء', 'العلوم الطبيعية', 'الفلسفة', 'اللغة العربية']

export default function App() {
  const [section, setSection] = useState('home')
  const [query, setQuery] = useState('')
  const [subject, setSubject] = useState('الكل')
  const [courses, setCourses] = useState(sampleCourses)
  const [user, setUser] = useState(null)
  const [authOpen, setAuthOpen] = useState(false)
  const [authMode, setAuthMode] = useState('signup')
  const [authEmail, setAuthEmail] = useState('')
  const [authPassword, setAuthPassword] = useState('')
  const [authName, setAuthName] = useState('')
  const [notice, setNotice] = useState('')
  const [busy, setBusy] = useState(false)
  const [mobileNav, setMobileNav] = useState(false)
  const [adminMode, setAdminMode] = useState(false)
  const [newCourse, setNewCourse] = useState({ title: '', subject: 'الرياضيات', description: '', video_url: '' })

  useEffect(() => {
    if (!hasSupabaseConfig) return
    supabase.auth.getSession().then(({ data }) => setUser(data.session?.user ?? null))
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => setUser(session?.user ?? null))
    supabase.from('courses').select('*').eq('published', true).order('created_at', { ascending: false })
      .then(({ data, error }) => { if (!error && data?.length) setCourses(data.map(c => ({...c, lessons: c.lessons_count ?? 0, duration: c.duration ?? 'حسب الدروس', color: 'blue', icon: '▶'}))) })
    return () => listener.subscription.unsubscribe()
  }, [])

  async function submitAuth(e) {
    e.preventDefault()
    if (!hasSupabaseConfig) { setNotice('اربط الموقع أولًا بمشروع Supabase باتباع ملف README.'); return }
    setBusy(true); setNotice('')
    try {
      if (authMode === 'signup') {
        const { error } = await supabase.auth.signUp({ email: authEmail, password: authPassword, options: { data: { full_name: authName } } })
        if (error) throw error
        setNotice('تم إنشاء الطلب. تحقق من بريدك الإلكتروني إذا كان تأكيد البريد مفعّلًا.')
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: authEmail, password: authPassword })
        if (error) throw error
        setAuthOpen(false)
      }
    } catch (err) { setNotice(err.message || 'تعذر إكمال العملية.') }
    finally { setBusy(false) }
  }

  async function logout() {
    if (supabase) await supabase.auth.signOut()
    setUser(null); setNotice('تم تسجيل الخروج.')
  }

  async function addCourse(e) {
    e.preventDefault()
    if (!supabase || !user) { setNotice('سجّل الدخول واربط قاعدة البيانات أولًا.'); return }
    const { error } = await supabase.from('courses').insert({ ...newCourse, published: true, created_by: user.id })
    if (error) setNotice('لم تتم الإضافة: ' + error.message)
    else {
      setNotice('أُضيفت الدورة إلى قاعدة البيانات.')
      const { data } = await supabase.from('courses').select('*').eq('published', true).order('created_at', { ascending: false })
      if (data) setCourses(data.map(c => ({...c, lessons: c.lessons_count ?? 0, duration: c.duration ?? 'حسب الدروس', color: 'blue', icon: '▶'})))
      setNewCourse({ title: '', subject: 'الرياضيات', description: '', video_url: '' })
    }
  }

  const visibleCourses = courses.filter(c => (subject === 'الكل' || c.subject === subject) && `${c.title} ${c.subject} ${c.description || ''}`.toLowerCase().includes(query.toLowerCase()))
  const navItems = [
    { id: 'home', label: 'الرئيسية', icon: LayoutDashboard },
    { id: 'courses', label: 'الدروس والدورات', icon: BookOpen },
    { id: 'documents', label: 'الوثائق والملخصات', icon: FileText },
    { id: 'community', label: 'مجتمع التلاميذ', icon: Users },
    { id: 'ai', label: 'مساعد الذكاء الاصطناعي', icon: BrainCircuit },
  ]

  function navigate(id) { setSection(id); setMobileNav(false); setNotice('') }

  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav ? 'mobile-open' : ''}`}>
      <div className="brand"><div className="brand-mark"><GraduationCap size={25}/></div><div><strong>BAC Academy <span>DZ</span></strong><small>طريقك نحو النجاح</small></div><button className="mobile-close icon-button" onClick={() => setMobileNav(false)}><X/></button></div>
      <div className="school-year"><span className="live-dot"/> موسم البكالوريا 2027 <ChevronLeft size={15}/></div>
      <div className="nav-caption">القائمة الرئيسية</div>
      <nav>{navItems.map(item => <button key={item.id} className={`nav-item ${section === item.id ? 'active' : ''}`} onClick={() => navigate(item.id)}><item.icon size={19}/><span>{item.label}</span>{item.id === 'ai' && <span className="new-pill">جديد</span>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="help-card"><div className="help-icon"><CircleHelp size={19}/></div><strong>تحتاج إلى مساعدة؟</strong><p>نحن هنا لمرافقتك في رحلة النجاح.</p><button onClick={() => setNotice('قريبًا: صفحة المساعدة والتواصل.')}>مركز المساعدة <ChevronLeft size={15}/></button></div><div className="sidebar-foot">صُنع بشغف في الجزائر <span>♥</span></div></div>
    </aside>
    {mobileNav && <button className="mobile-overlay" aria-label="إغلاق القائمة" onClick={() => setMobileNav(false)}/>}
    <main className="main-area">
      <header className="topbar"><div className="topbar-start"><button className="icon-button menu-toggle" onClick={() => setMobileNav(true)}><Menu/></button><div className="breadcrumb">أكاديمية البكالوريا <ChevronLeft size={14}/> <b>{navItems.find(n => n.id === section)?.label || 'لوحة التحكم'}</b></div></div><div className="top-actions"><label className="top-search"><Search size={17}/><input value={query} onChange={e => {setQuery(e.target.value); if(section === 'home') setSection('courses')}} placeholder="ابحث عن درس أو مادة..."/><kbd>⌘ K</kbd></label><button className="icon-button notification" onClick={() => setNotice('لا توجد إشعارات جديدة.')}><Bell size={19}/><i/></button>{user ? <button className="profile-button" onClick={logout}><span className="avatar">{(user.user_metadata?.full_name || user.email || 'ت').slice(0,1).toUpperCase()}</span><span className="profile-name">{user.user_metadata?.full_name || user.email}</span><LogOut size={16}/></button> : <button className="login-button" onClick={() => {setAuthMode('login');setAuthOpen(true)}}><LogIn size={16}/> دخول</button>}</div></header>
      <div className="page-content">
        {notice && <div className="notice"><span>{notice}</span><button onClick={() => setNotice('')}><X size={16}/></button></div>}
        {section === 'home' && <Home user={user} onNavigate={navigate} onAuth={() => {setAuthMode('signup');setAuthOpen(true)}} courses={courses}/>}
        {section === 'courses' && <section><div className="page-heading"><div><div className="eyebrow">مكتبة التعلّم <span/></div><h1>دروسك، خطوتك نحو النجاح.</h1><p>شرح مبسّط، تمارين تطبيقية، ومراجعة منظمة لكل المواد.</p></div><div className="heading-icon"><BookOpen size={28}/></div></div><div className="filter-row">{subjects.map(s => <button key={s} className={`filter-chip ${subject === s ? 'selected' : ''}`} onClick={() => setSubject(s)}>{s}</button>)}</div><div className="courses-grid">{visibleCourses.map(c => <CourseCard key={c.id} course={c} onOpen={() => setNotice(c.video_url ? 'رابط الدرس: ' + c.video_url : 'أضف فيديو أو دروسًا لهذه الدورة من لوحة الإدارة.')}/>)}</div>{visibleCourses.length === 0 && <div className="empty-state"><BookOpen size={32}/><strong>ما لقيناش نتائج</strong><p>جرّب كلمة بحث أخرى أو اختر مادة مختلفة.</p></div>}<div className="admin-panel"><div><h3><ShieldCheck size={19}/> إدارة المحتوى</h3><p>أضف دورة جديدة إلى قاعدة البيانات (تتطلب تسجيل الدخول وصلاحية الإدارة في Supabase).</p></div><button className="secondary-button" onClick={() => setAdminMode(!adminMode)}>{adminMode ? 'إغلاق' : 'إضافة دورة'} <ChevronLeft size={16}/></button></div>{adminMode && <form className="admin-form" onSubmit={addCourse}><label>عنوان الدورة<input required value={newCourse.title} onChange={e=>setNewCourse({...newCourse,title:e.target.value})} placeholder="مثال: الاشتقاق"/></label><label>المادة<select value={newCourse.subject} onChange={e=>setNewCourse({...newCourse,subject:e.target.value})}>{subjects.filter(s=>s!=='الكل').map(s=><option key={s}>{s}</option>)}</select></label><label>وصف الدورة<textarea value={newCourse.description} onChange={e=>setNewCourse({...newCourse,description:e.target.value})} placeholder="ماذا سيتعلم التلميذ؟"/></label><label>رابط الفيديو (اختياري)<input type="url" value={newCourse.video_url} onChange={e=>setNewCourse({...newCourse,video_url:e.target.value})} placeholder="https://..."/></label><button className="primary-button" type="submit">حفظ الدورة</button></form>}</section>}
        {section === 'documents' && <section><div className="page-heading"><div><div className="eyebrow">ملفات البكالوريا <span/></div><h1>كل الوثائق في مكان واحد.</h1><p>ملخصات، مواضيع سابقة، وسلاسل تمارين منظمة حسب المادة.</p></div><div className="heading-icon"><FileText size={28}/></div></div><div className="coming-card"><div className="coming-illustration"><FileText size={35}/></div><h2>مكتبة الوثائق قيد التحضير</h2><p>ستتمكن قريبًا من تصفح وتنزيل ملفات PDF حسب الشعبة والمادة والسنة.</p><button className="primary-button" onClick={() => setNotice('تم تسجيل اهتمامك بمكتبة الوثائق محليًا.')}>ذكّرني عند الإطلاق <Bell size={16}/></button></div></section>}
        {section === 'community' && <section><div className="page-heading"><div><div className="eyebrow">نتعلم معًا <span/></div><h1>النجاح أحلى كي نتقاسموه.</h1><p>مساحة للنقاش وطرح الأسئلة وتبادل الأفكار مع زملائك.</p></div><div className="heading-icon"><Users size={28}/></div></div><div className="coming-card"><div className="coming-illustration"><Users size={35}/></div><h2>مجتمع التلاميذ قادم</h2><p>سيكون فيه نقاش حسب المواد، أسئلة يومية، وتحديات بين التلاميذ.</p><button className="primary-button" onClick={() => setNotice('ميزة المجتمع ما زالت تحتاج إلى إعداد إضافي.')}>اكتشف قريبًا <Sparkles size={16}/></button></div></section>}
        {section === 'ai' && <section><div className="page-heading"><div><div className="eyebrow">رفيق المراجعة الذكي <span/></div><h1>اسأل. افهم. تقدّم.</h1><p>مساعد دراسي مصمم لمرافقتك في التحضير للبكالوريا الجزائرية.</p></div><div className="heading-icon"><BrainCircuit size={28}/></div></div><div className="coming-card"><div className="coming-illustration"><BrainCircuit size={35}/></div><h2>مساعد الذكاء الاصطناعي</h2><p>لربطه فعليًا، يلزم إعداد خدمة ذكاء اصطناعي ومفتاح API على الخادم، وليس داخل المتصفح.</p><button className="primary-button" onClick={() => setNotice('ستحتاج إلى إعداد خادم آمن ومفتاح API قبل تفعيل الذكاء الاصطناعي.')}>كيف نفعّله؟ <ChevronLeft size={16}/></button></div></section>}
      </div>
      <footer className="footer"><span>© 2026 BAC Academy DZ</span><span>من الجزائر، لكل طالب يحلم بالنجاح <span className="heart">♥</span></span><span className={`connection ${hasSupabaseConfig ? 'connected' : ''}`}><i/>{hasSupabaseConfig ? 'إعداد قاعدة البيانات موجود' : 'وضع المعاينة — غير مربوط بقاعدة البيانات'}</span></footer>
    </main>
    {authOpen && <div className="modal-backdrop" onMouseDown={e => {if(e.target === e.currentTarget)setAuthOpen(false)}}><div className="auth-modal"><button className="modal-close icon-button" onClick={() => setAuthOpen(false)}><X/></button><div className="auth-logo"><GraduationCap size={26}/></div><h2>{authMode === 'signup' ? 'أنشئ حسابك مجانًا' : 'مرحبًا بعودتك'}</h2><p>ابدأ رحلتك نحو بكالوريا أفضل.</p><form onSubmit={submitAuth}>{authMode === 'signup' && <label>الاسم الكامل<input required value={authName} onChange={e=>setAuthName(e.target.value)} placeholder="اسمك ولقبك"/></label>}<label>البريد الإلكتروني<input type="email" required value={authEmail} onChange={e=>setAuthEmail(e.target.value)} placeholder="you@example.com" dir="ltr"/></label><label>كلمة المرور<input type="password" minLength="6" required value={authPassword} onChange={e=>setAuthPassword(e.target.value)} placeholder="6 أحرف على الأقل" dir="ltr"/></label><button className="primary-button auth-submit" disabled={busy}>{busy ? 'لحظة من فضلك...' : authMode === 'signup' ? <><UserPlus size={17}/> إنشاء الحساب</> : <><LogIn size={17}/> تسجيل الدخول</>}</button></form><button className="auth-switch" onClick={() => {setAuthMode(authMode === 'signup' ? 'login' : 'signup');setNotice('')}}>{authMode === 'signup' ? 'عندك حساب؟ سجّل الدخول' : 'ما عندكش حساب؟ أنشئ حسابًا'}</button>{!hasSupabaseConfig && <div className="auth-warning"><LockKeyhole size={15}/> التسجيل يشتغل بعد إعداد Supabase.</div>}</div></div>}
  </div>
}

function Home({ user, onNavigate, onAuth, courses }) {
  return <section className="home-view">
    <div className="welcome-row"><div><div className="eyebrow"><span/> منصة التحضير للبكالوريا الجزائرية</div><h1>مستقبلك يبدأ <span>بخطوة.</span></h1><p className="welcome-copy">نظّم مراجعتك، افهم دروسك، وقرّب حلمك بالنجاح يومًا بعد يوم.</p><div className="welcome-actions"><button className="primary-button" onClick={() => onNavigate('courses')}>اكتشف الدروس <ChevronLeft size={17}/></button>{!user && <button className="secondary-button" onClick={onAuth}>أنشئ حسابك <UserPlus size={17}/></button>}</div><div className="trust-line"><div className="mini-avatars"><span>ت</span><span>م</span><span>ن</span></div><span>خطوة بخطوة نحو هدفك</span><span className="trust-star"><Star size={14} fill="currentColor"/> محتوى منظم</span></div></div><div className="hero-art"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="hero-book"><GraduationCap size={76} strokeWidth={1.4}/><div className="book-line"/></div><div className="float-card float-card-top"><span className="float-icon green"><CheckCircle2 size={19}/></span><div><b>كل يوم تقدّم</b><small>واصل المراجعة!</small></div></div><div className="float-card float-card-bottom"><span className="float-icon purple"><BrainCircuit size={19}/></span><div><b>تعلّم بذكاء</b><small>بأسلوبك الخاص</small></div></div><div className="hero-sparkle sparkle-one">✦</div><div className="hero-sparkle sparkle-two">✧</div></div></div>
    <div className="stats-grid"><Stat icon={BookOpen} value={`${courses.length}+`} label="دورات تعليمية" color="blue"/><Stat icon={Users} value="2027" label="موسم البكالوريا" color="purple"/><Stat icon={BrainCircuit} value="24/7" label="تعلّم على راحتك" color="orange"/><Stat icon={GraduationCap} value="DZ" label="محتوى جزائري" color="green"/></div>
    <div className="section-title-row"><div><span className="section-kicker">ابدأ من هنا</span><h2>ماذا تحتاج اليوم؟</h2><p>اختر المسار الذي يساعدك على التقدّم.</p></div><button className="text-link" onClick={() => onNavigate('courses')}>عرض كل الدروس <ChevronLeft size={16}/></button></div>
    <div className="feature-grid"><Feature icon={PlayCircle} title="دروس بالفيديو" text="شرح واضح ومتدرج للمفاهيم الأساسية." color="blue" onClick={() => onNavigate('courses')}/><Feature icon={FileText} title="وثائق وملخصات" text="راجع أهم القواعد والتمارين في أي وقت." color="orange" onClick={() => onNavigate('documents')}/><Feature icon={BrainCircuit} title="مساعد ذكي" text="حضّر أسئلتك واكتشف طرقًا جديدة للفهم." color="purple" onClick={() => onNavigate('ai')}/></div>
    <div className="section-title-row courses-title"><div><span className="section-kicker">اختيرت لك</span><h2>دورات تساعدك على الانطلاق</h2><p>ابدأ بالمادة التي تريد تحسين مستواك فيها.</p></div><button className="text-link" onClick={() => onNavigate('courses')}>كل الدورات <ChevronLeft size={16}/></button></div>
    <div className="courses-grid home-courses">{courses.slice(0,3).map(c => <CourseCard key={c.id} course={c} onOpen={() => onNavigate('courses')}/>)}</div>
    <div className="motivation-banner"><div className="motivation-icon"><Sparkles size={23}/></div><div><strong>ما تحتاجش تكون ممتاز من اليوم الأول.</strong><p>المهم تبدأ، تستمر، وكل يوم تزيد خطوة صغيرة.</p></div><div className="banner-decoration">بالتوفيق <span>✦</span></div></div>
  </section>
}
function Stat({icon: Icon, value, label, color}) { return <div className="stat-card"><div className={`stat-icon ${color}`}><Icon size={20}/></div><div><strong>{value}</strong><span>{label}</span></div></div> }
function Feature({icon: Icon,title,text,color,onClick}) { return <button className="feature-card" onClick={onClick}><div className={`feature-icon ${color}`}><Icon size={23}/></div><div className="feature-text"><strong>{title}</strong><p>{text}</p></div><ChevronLeft className="feature-arrow" size={18}/></button> }
function CourseCard({course,onOpen}) { return <article className="course-card"><div className={`course-cover ${course.color || 'blue'}`}><div className="cover-pattern"/><span className="course-subject">{course.subject}</span><div className="cover-symbol">{course.icon || '∑'}</div><span className="course-level">{course.level || 'دورة تعليمية'}</span></div><div className="course-body"><div className="course-teacher"><span className="teacher-avatar"><GraduationCap size={16}/></span><span>{course.teacher || 'فريق BAC Academy'}</span><span className="verified"><CheckCircle2 size={14}/></span></div><h3>{course.title}</h3><p>{course.description || 'شرح مبسّط مع أمثلة وتمارين تطبيقية تساعدك على الفهم.'}</p><div className="course-meta"><span><PlayCircle size={15}/> {course.lessons ?? 0} دروس</span><span><Clock3 size={15}/> {course.duration || 'متاح دائمًا'}</span></div><button className="course-button" onClick={onOpen}>اكتشف الدورة <ChevronLeft size={16}/></button></div></article> }