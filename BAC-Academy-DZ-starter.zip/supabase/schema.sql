-- BAC Academy DZ starter schema
-- Run this entire file in Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'student' check (role in ('student','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.courses (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  subject text not null,
  description text not null default '',
  video_url text,
  duration text not null default 'حسب الدروس',
  lessons_count integer not null default 0 check (lessons_count >= 0),
  published boolean not null default false,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.enrollments (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references auth.users(id) on delete cascade,
  course_id uuid not null references public.courses(id) on delete cascade,
  enrolled_at timestamptz not null default now(),
  unique(student_id, course_id)
);

create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  subject text not null,
  file_path text not null,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.courses enable row level security;
alter table public.enrollments enable row level security;
alter table public.documents enable row level security;

-- Profiles: a user can read/update only their own profile.
create policy "profiles read own" on public.profiles
for select to authenticated using (auth.uid() = id);
create policy "profiles update own name" on public.profiles
for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- Public can read published courses; only admins may create/update/delete courses.
create policy "published courses readable" on public.courses
for select to anon, authenticated using (published = true or exists (
  select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'
));
create policy "admins insert courses" on public.courses
for insert to authenticated with check (exists (
  select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'
));
create policy "admins update courses" on public.courses
for update to authenticated using (exists (
  select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'
)) with check (exists (
  select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'
));
create policy "admins delete courses" on public.courses
for delete to authenticated using (exists (
  select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'
));

-- Enrollments are private to each student. Admins can inspect/manage them.
create policy "students read own enrollments" on public.enrollments
for select to authenticated using (student_id = auth.uid() or exists (
  select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'
));
create policy "students enroll themselves" on public.enrollments
for insert to authenticated with check (student_id = auth.uid());
create policy "admins manage enrollments" on public.enrollments
for all to authenticated using (exists (
  select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'
)) with check (exists (
  select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'
));

create policy "published documents readable" on public.documents
for select to anon, authenticated using (published = true or exists (
  select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'
));
create policy "admins manage documents" on public.documents
for all to authenticated using (exists (
  select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'
)) with check (exists (
  select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'
));

-- Create a profile row whenever a user signs up.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name', ''));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- IMPORTANT: Promote your own account to admin manually after signing up:
-- update public.profiles set role = 'admin' where id = 'YOUR_AUTH_USER_UUID';
